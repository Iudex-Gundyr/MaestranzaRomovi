<!DOCTYPE html>
<html>
<head>
    <title>Mensaje de Contacto</title>
</head>
<body>
    <p>Nombre: {{ $details['nombre'] }}</p>
    <p>Correo: {{ $details['correo'] }}</p>
    <p>Teléfono: {{ $details['telefono'] }}</p>
    <p>Mensaje: {{ $details['mensaje'] }}</p>
</body>
</html>