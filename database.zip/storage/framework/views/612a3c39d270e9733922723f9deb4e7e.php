<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Agregar Entrada</title>
</head>
<body>
    <?php echo $__env->make('Intranet/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Contenido principal -->
    <div class="container" style="margin-left: 250px; padding: 20px;">

        <h1 style="text-align: center">Agregar material a un almacen de <?php echo e($ubicacion->nombreu); ?></h1>

        <form action="<?php echo e(route('registrarEntrada', $ubicacion->id_ubicacion)); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- Para protección contra ataques CSRF en Laravel -->
            <label for="nombre">Nombre del almacen:</label>
            <select name="id_almacen" id="id_almacen" style="padding: 10px; margin-bottom: 20px; border: 2px solid #ccc; border-radius: 4px; width: 50%;">
                <option value="">-</option>
                <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($almacen->id_almacen); ?>"><?php echo e($almacen->nombrea); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="nombre">Material</label>
            <select name="id_material" id="id_material" style="padding: 10px; margin-bottom: 20px; border: 2px solid #ccc; border-radius: 4px; width: 50%;">
                <option value="">-</option>
                <?php $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($material->id_material); ?>"><?php echo e($material->nombrema); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="cantidad">Cantidad:</label>
            <input class="input" type="number" id="cantidad" name="cantidad" step="0.001" value="<?php echo e(old('cantidad')); ?>" required>
            <label for="valor">Valor de la entrada $CLP:</label>
            <input  type="text" id="valor" name="valor" value="<?php echo e(old('valor')); ?>" required>
            <button type="submit">Crear entrada</button>
        
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" style="background-color: #ffcccc; color: #cc0000; padding: 10px; border-radius: 5px;">
                    <ul style="list-style-type: none; padding: 0;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </form>
    </div>

</body>
</html>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/Entradas/CrearEntrada.blade.php ENDPATH**/ ?>