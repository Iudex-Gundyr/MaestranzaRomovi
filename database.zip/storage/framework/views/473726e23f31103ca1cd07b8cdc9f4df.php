<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Materiales</title>
</head>
<body>
    <?php echo $__env->make('Intranet/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Contenido principal -->

    <div class="container" style="margin-left: 250px; padding: 20px;">
        <div style="text-align: center;">
        <a href="/CrearMaterial" class="btn">Crear nuevo Material</a>
        </div><br>
        <h4 style="text-align: center">Se muestran los materiales que contengan "<?php echo e($filtro); ?>" en su nombre</h4>
        <?php if(session('success')): ?>
            <div class="alert alert-success text-center">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('Buscarmateriales')); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- Para protección contra ataques CSRF en Laravel -->
            <label for="nombre">Buscar por nombre (Buscar los materiales con lo mas parecido escrito):</label>
            <input type="text" id="nombrema" name="nombrema" value="<?php echo e(old('nombrema')); ?>" required>
        
            <button type="submit">Buscar</button>
        
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" style="background-color: #ffcccc; color: #cc0000; padding: 10px; border-radius: 5px;">
                    <ul style="list-style-type: none; padding: 0;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </form>
        <table>
            <thead>
                <tr>
                    <th>Nombre del material</th>
                    <th>Tipo de medida</th>
                    <th>Cantidad de seguridad</th>
                    <th>opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($material->nombrema); ?></td>
                    <td><?php echo e($material->medida->nombrem); ?></td>
                    <td><?php echo e($material->cantidad_seguridad); ?></td>
                    <td>
                        <a href="/examinarMaterial/<?php echo e($material->id_material); ?>" class="btnExaminar">Examinar</a>
                        <a href="#" onclick="confirmarEliminarMaterial(<?php echo e($material->id_material); ?>)" class="btnEliminar">Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
            </tbody>

        </table>
    </div>

</body>
</html>
<?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/Materiales/Buscarmateriales.blade.php ENDPATH**/ ?>