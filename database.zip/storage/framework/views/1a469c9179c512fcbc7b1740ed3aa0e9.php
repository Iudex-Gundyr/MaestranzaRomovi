<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <img src="<?php echo e(asset('img/LogoRomovi.png')); ?>" alt="Logo de la empresa" class="logo">
        <h2>Iniciar Sesión</h2>
        <form action="<?php echo e(route('IniciarSesion')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <label for="email">Correo:</label>
                <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color: red;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color: red;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php if($errors->has('mensaje')): ?>
                <span style="color: red;"><?php echo e($errors->first('mensaje')); ?></span>
            <?php endif; ?><br>
            <button type="submit" class="btn">Iniciar Sesión</button>
        </form>
    </div>
</body>
</html><?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/login.blade.php ENDPATH**/ ?>