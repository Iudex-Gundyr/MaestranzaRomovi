<!DOCTYPE html>
<html>
<head>
    <title>Mensaje de Contacto</title>
</head>
<body>
    <p>Nombre: <?php echo e($details['nombre']); ?></p>
    <p>Correo: <?php echo e($details['correo']); ?></p>
    <p>Teléfono: <?php echo e($details['telefono']); ?></p>
    <p>Mensaje: <?php echo e($details['mensaje']); ?></p>
</body>
</html><?php /**PATH E:\Mis proyectos\Romovi files\romovi\resources\views/emails/contact.blade.php ENDPATH**/ ?>