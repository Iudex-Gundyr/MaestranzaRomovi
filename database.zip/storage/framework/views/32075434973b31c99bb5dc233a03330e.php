<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>
</head>
<body>
    <?php echo $__env->make('Intranet/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Contenido principal -->

    <div class="container" style="margin-left: 250px; padding: 20px;">
        <button class="btn">Crear nuevo usuario</button>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Contraseña</th>
                    <th>Opciones</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>John</td>
                    <td>Doe</td>
                    <td>30</td>
                    <td><button class="btnExaminar">Examinar</button><button class="btnEliminar">Eliminar</button></td>
                </tr>
                <tr>
                    <td>John</td>
                    <td>Doe</td>
                    <td>30</td>
                    <td><button class="btnExaminar">Examinar</button><button class="btnEliminar">Eliminar</button></td>
                </tr>
                <tr>
                    <td>John</td>
                    <td>Doe</td>
                    <td>30</td>
                    <td><button class="btnExaminar">Examinar</button><button class="btnEliminar">Eliminar</button></td>
                </tr>
                <tr>
                    <td>John</td>
                    <td>Doe</td>
                    <td>30</td>
                    <td><button class="btnExaminar">Examinar</button><button class="btnEliminar">Eliminar</button></td>
                </tr>
                <tr>
                    <td>John</td>
                    <td>Doe</td>
                    <td>30</td>
                    <td><button class="btnExaminar">Examinar</button><button class="btnEliminar">Eliminar</button></td>
                </tr>
                
            </tbody>
        </table>
    </div>

</body>
</html>
<?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/usuarios.blade.php ENDPATH**/ ?>