<!DOCTYPE html>
<html>
<head>
    <title>Mensaje de Contacto</title>
</head>
<body>
    <p>Nombre: <?php echo e($details['nombre']); ?></p>
    <p>Correo: <?php echo e($details['correo']); ?></p>
    <p>Teléfono: <?php echo e($details['telefono']); ?></p>
    <p>Mensaje: <?php echo e($details['mensaje']); ?></p>
</body>
</html><?php /**PATH /home/romovi/Platform/resources/views/emails/contact.blade.php ENDPATH**/ ?>