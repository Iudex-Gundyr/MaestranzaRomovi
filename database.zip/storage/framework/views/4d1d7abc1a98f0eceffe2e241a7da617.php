<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Materiales Almacen</title>
</head>
<body>
    <?php echo $__env->make('Intranet/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Contenido principal -->

    <div class="container" style="margin-left: 250px; padding: 20px;">
        <?php $__currentLoopData = $matalm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materialAlmacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h1 style="text-align: center">Materiales de almacenes de <?php echo e($materialAlmacen->almacen->ubicacion->nombreu); ?></h1>
            <?php break; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(isset($success)): ?>
            <div class="alert alert-success" style="background-color:green">
                <?php echo e($success); ?>

            </div>
        <?php endif; ?>
        <?php if(isset($error)): ?>
            <div class="alert alert-danger" style="background-color: red">
                <?php echo e($error); ?>

            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $matalm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materialAlmacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('buscarMaterialAlmacen',$materialAlmacen->almacen->ubicacion->id_ubicacion)); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- Para protección contra ataques CSRF en Laravel -->
            <label for="nombre">Buscar por nombre (Buscar los materiales con lo mas parecido escrito):</label>
            <input type="text" id="nombrema" name="nombrema" value="<?php echo e(old('nombrema')); ?>" required>
        
            <button type="submit">Buscar</button>
        
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" style="background-color: #ffcccc; color: #cc0000; padding: 10px; border-radius: 5px;">
                    <ul style="list-style-type: none; padding: 0;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </form>
        <?php break; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <table>
            <thead>
                <tr>
                    <th>Nombre del material</th>
                    <th>Cantidad Actual</th>
                    <th>Cantidad de seguridad</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($dato->nombrema); ?></td>
                    <td><?php echo e($dato->suma_entrada - $dato->suma_salida); ?>   /   <?php echo e($dato->nombrem); ?></td>
                    <td><?php echo e($dato->cantidad_seguridad); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
            </tbody>

        </table>
    </div>

</body>
</html>
<?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/MaterialAlmacen/MaterialAlmacen.blade.php ENDPATH**/ ?>