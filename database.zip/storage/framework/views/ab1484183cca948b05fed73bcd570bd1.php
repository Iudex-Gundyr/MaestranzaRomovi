<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Salidas</title>
</head>
<body>
    <?php echo $__env->make('Intranet/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Contenido principal -->

    <div class="container" style="margin-left: 250px; padding: 20px;">
        <?php $__currentLoopData = $salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h1 style="text-align: center">Salidas de materiales de almacenes de <?php echo e($salida->materialAlmacen->almacen->ubicacion->nombreu); ?></h1>
            <?php break; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div style="text-align: center;">
            <a style="margin-bottom:15px" href="/CrearSalida/<?php echo e($id_ubicacion); ?>" class="btn">Crear nueva Salida</a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success" style="background-color:green">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(isset($error)): ?>
            <div class="alert alert-danger" style="background-color: red">
                <?php echo e($error); ?>

            </div>
        <?php endif; ?>


        <table>
            <thead>
                <tr>
                    <th>Nombre del material</th>
                    <th>En el Almacen</th>
                    <th>Cantidad de salida</th>

                    <th>opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($salida->cantidad > 0 ): ?>
                    <tr>

                        <td><?php echo e($salida->materialAlmacen->material->nombrema); ?></td>
                        <td><?php echo e($salida->materialAlmacen->almacen->nombrea); ?></td>
                        <td>
                            <?php echo e(rtrim(rtrim(number_format($salida->cantidad, 5), '0'), '.')); ?> <!-- Mostrar el número con máximo 4 decimales y sin ceros finales -->

                        </td>
                        <td>
                            <a href="#" onclick="confirmarEliminarSalida(<?php echo e($id_ubicacion); ?>,<?php echo e($salida->id_salida); ?>)" class="btnEliminar">Eliminar</a>
                        </td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</body>
</html>
<?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/Salidas/Salidas.blade.php ENDPATH**/ ?>