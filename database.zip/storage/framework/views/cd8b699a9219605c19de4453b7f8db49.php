<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Entradas</title>
</head>
<body>
    <?php echo $__env->make('Intranet/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Contenido principal -->

    <div class="container" style="margin-left: 250px; padding: 20px;">
        <?php $__currentLoopData = $entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h1 style="text-align: center">Entradas de materiales de almacenes de <?php echo e($entrada->materialAlmacen->almacen->ubicacion->nombreu); ?></h1>
            <?php break; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div style="text-align: center;">
            <a style="margin-bottom:15px" href="/CrearEntrada/<?php echo e($id_ubicacion); ?>" class="btn">Crear nueva entrada</a>


        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success" style="background-color:green">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(isset($error)): ?>
            <div class="alert alert-danger" style="background-color: red">
                <?php echo e($error); ?>

            </div>
        <?php endif; ?>


        <table>
            <thead>
                <tr>
                    <th>Nombre del material</th>
                    <th>En el Almacen</th>
                    <th>Cantidad</th>
                    <th>Valor entrada (CLP)</th>
                    <th>opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($entrada->materialAlmacen->material->nombrema); ?></td>
                    <td><?php echo e($entrada->materialAlmacen->almacen->nombrea); ?></td>
                    <td>
                        <?php echo e(rtrim(rtrim(number_format($entrada->cantidad, 5), '0'), '.')); ?> <!-- Mostrar el número con máximo 4 decimales y sin ceros finales -->
                    </td>
                    <td><?php echo e(number_format($entrada->valor, 0, ',', '.')); ?> CLP</td>
                    <td>
                        <a href="#" onclick="confirmarEliminarEntrada(<?php echo e($id_ubicacion); ?>,<?php echo e($entrada->id_entrada); ?>)" class="btnEliminar">Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</body>
</html>
<?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/Entradas/Entradas.blade.php ENDPATH**/ ?>