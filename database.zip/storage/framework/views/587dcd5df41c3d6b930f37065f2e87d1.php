<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Agregar Salidas</title>
</head>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<body>
    <?php echo $__env->make('Intranet/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Contenido principal -->
    <div class="container" style="margin-left: 250px; padding: 20px;">

        <h1 style="text-align: center">Saca materiales a un almacen de <?php echo e($ubicacion->nombreu); ?></h1>
        <form id="formulario" action="<?php echo e(route('RegistrarSalida', $ubicacion->id_ubicacion)); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- Para protección contra ataques CSRF en Laravel -->
            <label for="nombre">Nombre del almacen:</label>
            <select name="id_almacen" id="id_almacen" style="padding: 10px; margin-bottom: 20px; border: 2px solid #ccc; border-radius: 4px; width: 50%;">
                <option value="">-</option>
                <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($almacen->id_almacen); ?>"><?php echo e($almacen->nombrea); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="nombre">Material</label>
            <select name="id_mat_alm" id="id_mat_alm" style="padding: 10px; margin-bottom: 20px; border: 2px solid #ccc; border-radius: 4px; width: 50%;" required>
        
            </select>
            <label for="cantidad">Cantidad:</label>
            <input class="input" type="number" id="cantidad" name="cantidad" step="0.001" value="<?php echo e(old('cantidad')); ?>" required>
            <label for="suma_cantidad">No puedes superar la siguiente cantidad:</label>
            <input class="input" type="number" id="suma_cantidad" step="0.001" readonly>
            <button id="botonCrearSalida" type="submit" disabled>Crear salida</button>
            <p id="mensajeError" style="color: red;"></p>
        
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" style="background-color: #ffcccc; color: #cc0000; padding: 10px; border-radius: 5px;">
                    <ul style="list-style-type: none; padding: 0;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </form>
    </div>

</body>
</html>


<script>
    $('#id_almacen').change(function() {
        var selectedAlmacenId = $(this).val();
        var materialSelect = $('#id_mat_alm');
    
        // Limpiar el select de materiales
        materialSelect.empty();
    
        // Agregar primer ítem vacío
        materialSelect.append('<option value="" disabled selected>- Seleccione un material -</option>');
    
        // Verificar si el valor seleccionado del almacén es válido
        if (selectedAlmacenId) {
            // Realizar la solicitud AJAX
            $.get('/obtenerMateriales/' + selectedAlmacenId, function(data) {
                // Llenar el select de materiales con los datos recibidos
                $.each(data, function(index, material) {
                    materialSelect.append('<option  id="id_mat_alm" value="' + material.id_mat_alm + '">' + material.material.nombrema + '</option>');
                });
            });
        }
    });
    
    $('#id_mat_alm').change(function() {
        var idMatAlm = $(this).val();
        
        $.get('/obtenerSumaCantidad/' + idMatAlm, function(response) {
            console.log(response); // Verificar la respuesta en la consola del navegador
            var sumaCantidad = parseFloat(response);
            if (!isNaN(sumaCantidad)) {
                $('#suma_cantidad').val(sumaCantidad.toFixed(3)); // Convertir y establecer el valor en el input
            } else {
                console.error('El valor recibido no es un número válido:', response);
            }
        });
    });

    $(document).ready(function() {
    $('#cantidad').keyup(function() {
        var cantidad = parseFloat($(this).val());
        var sumaCantidad = parseFloat($('#suma_cantidad').val());
        
        console.log("Cantidad:", cantidad);
        console.log("Suma cantidad:", sumaCantidad);

        if (!isNaN(cantidad) && !isNaN(sumaCantidad)) {
            if (cantidad > sumaCantidad) {
                $('#mensajeError').text('La cantidad no puede superar la suma de cantidad.');
                $('#botonCrearSalida').prop('disabled', true);
            } else {
                $('#mensajeError').text('');
                $('#botonCrearSalida').prop('disabled', false);
            }
        }
    });
});
    </script><?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/Salidas/CrearSalidas.blade.php ENDPATH**/ ?>