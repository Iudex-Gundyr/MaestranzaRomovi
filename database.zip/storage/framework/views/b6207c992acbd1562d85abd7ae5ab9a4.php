<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="<?php echo e(asset('css/Intranet.css')); ?>" rel="stylesheet">

</head>
<body>
    <div class="navbar">
  
        <ul>
            <img src="<?php echo e(asset('img/LogoRomovi.png')); ?>" alt="Logo de la empresa" class="logo">
            <li class="open"><a href="/dashboard"><i class="fa fa-building" aria-hidden="true"></i>Dashboard</a></li>
            <li>
                <a href="#"><i class="fas fa-bars" aria-hidden="true"></i>Almacenes<i class="fa fa-arrow-down arrow-icon" aria-hidden="true"></i></a>
                <ul class="sub-menu">
                <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="/MaterialAlmacen/<?php echo e($ubicacion->id_ubicacion); ?>"><i class="fa fa-compass" aria-hidden="true"></i><?php echo e($ubicacion->nombreu); ?></a>
                        <ul>
                            <li><a href="/Entradas/<?php echo e($ubicacion->id_ubicacion); ?>" ><i class="fa fa-compass" aria-hidden="true"></i>Entradas</a></li>
                            <li><a href="/Salidas/<?php echo e($ubicacion->id_ubicacion); ?>" ><i class="fa fa-compass" aria-hidden="true"></i>Salidas</a></li>
                        </ul>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li class="parent"><a href="#"><i class="fas fa-cog"></i>Configuración<i class="fa fa-arrow-down arrow-icon" aria-hidden="true"></i></a>
                <ul class="sub-menu">
                    <li><a href="/ubicaciones"><i class="fa fa-compass" aria-hidden="true"></i>Ubicaciones</a></li>
                    <li><a href="/Almacenes"><i class="fa fa-archive" aria-hidden="true"></i>Almacenes</a></li>
                    <li><a href="/unidadesMedidas"><i class="fa fa-list-ol" aria-hidden="true"></i>Unidades de medida</a></li>
                    <li><a href="/Materiales"><i class="fa fa-tag" aria-hidden="true"></i>Materiales</a></li>
                    <li><a href="/Usuarios"><i class="fa fa-user" aria-hidden="true"></i>Usuarios</a></li>
                </ul>
            </li>
        </ul>
    </div>
</body>
</html>
<script src="<?php echo e(asset('js/Intranet.js')); ?>"></script><?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/navbar.blade.php ENDPATH**/ ?>