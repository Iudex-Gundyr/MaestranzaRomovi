<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Crear Usuario</title>
</head>
<body>
    <?php echo $__env->make('Intranet/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Contenido principal -->
    <div class="container" style="margin-left: 250px; padding: 20px;">
        <h2>Crear Usuario</h2>
        <form action="<?php echo e(route('modificarUsuario', $usuario->id_usuario)); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- Para protección contra ataques CSRF en Laravel -->
            <?php echo method_field('PUT'); ?> <!-- Para indicar que usaremos el método PUT en el envío del formulario -->
        
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo e($usuario->nombre); ?>" required>
        
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo e($usuario->email); ?>" required>
        
            <label for="password">Contraseña (Dejar en blanco si no desea modificar):</label>
            <input type="password" id="password" name="password">
        
            <button type="submit">Modificar Usuario</button>
        
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" style="background-color: #ffcccc; color: #cc0000; padding: 10px; border-radius: 5px;">
                    <ul style="list-style-type: none; padding: 0;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </form>
    </div>

</body>
</html>
<?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/usuarios/ModificarUsuario.blade.php ENDPATH**/ ?>