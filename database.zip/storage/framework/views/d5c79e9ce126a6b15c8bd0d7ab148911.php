<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>
</head>
<body>
    <?php echo $__env->make('Intranet/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Contenido principal -->
    <div style="margin-left: 250px; padding: 20px;">
        <h1 style="text-align: center">Materiales bajo el stock de seguridad</h1>
        <div class="gastos">
            <div class="gasto">
                Gastos últimos 30 días
            </div>

            <div class="gasto">
                Gastos últimos 6 meses
            </div>

            <div class="gasto">
                Gastos últimos 12 meses
            </div>

        </div>
        <div class="gastos">
            <div class="gasto1">
                $<?php echo e(number_format($suma1, 0, ',', '.')); ?> CLP
            </div>
            <div class="gasto1">
                $<?php echo e(number_format($suma6, 0, ',', '.')); ?> CLP
            </div>
            <div class="gasto1">
                $<?php echo e(number_format($suma12, 0, ',', '.')); ?> CLP
            </div>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Nombre del material</th>
                    <th>Ubicacion</th>
                    <th>Cantidad actual/Tipo Medida</th>
                    <th>Cantidad de seguridad</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    

                    <tr>
                        <td><?php echo e($dato->nombrema); ?></td>
                        <td><?php echo e($dato->nombreu); ?></td>
                        <td style="color: red"><?php echo e($dato->suma_entrada - $dato->suma_salida); ?>   /   <?php echo e($dato->nombrem); ?></td>
                        <td><?php echo e($dato->cantidad_seguridad); ?></td>

                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/dashboard.blade.php ENDPATH**/ ?>