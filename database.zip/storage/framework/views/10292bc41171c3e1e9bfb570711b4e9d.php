<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Almacenes</title>
</head>
<body>
    <?php echo $__env->make('Intranet/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Contenido principal -->

    <div class="container" style="margin-left: 250px; padding: 20px;">
        <div style="text-align: center;">
        <a href="/CrearAlmacen" class="btn">Crear nuevo almacen</a>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success text-center">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <table>
            <thead>
                <tr>
                    <th>Nombre del almacen</th>
                    <th>Ubicacion del almacen</th>
                    <th>Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($almacen->nombrea); ?></td>
                    <td><?php echo e($almacen->ubicacion->nombreu); ?></td>
                    <td>
                        <a href="/examinarAlmacen/<?php echo e($almacen->id_almacen); ?>" class="btnExaminar">Examinar</a>
                        <a href="#" onclick="confirmarEliminarAlmacenes(<?php echo e($almacen->id_almacen); ?>)" class="btnEliminar">Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>

</body>
</html>
<?php /**PATH E:\Mis proyectos\Romovi files\Romovi Files\resources\views/Intranet/Almacenes/almacenes.blade.php ENDPATH**/ ?>