<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Medida extends Model
{
    protected $table = 'medida';
    protected $primaryKey = 'id_medida';
    
    protected $fillable = [
        'nombrem',
    ];
}